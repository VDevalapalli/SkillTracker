// import { TestBed } from '@angular/core/testing';

// import { UserAuthService } from './user-auth.service';

// describe('UserAuthService', () => {
//   let service: UserAuthService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(UserAuthService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });


import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { UserAuthService } from './user-auth.service';
import { AuthStorageService } from './auth-storage.service';
import { AUTH_URLS } from '../constants/api-url.const';

describe('UserAuthService', () => {
  let service: UserAuthService;
  let httpMock: HttpTestingController;
  let authStorageServiceSpy: jasmine.SpyObj<AuthStorageService>;

  beforeEach(() => {
    const authStorageSpy = jasmine.createSpyObj('AuthStorageService', ['getRole', 'getToken', 'clear']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        UserAuthService,
        { provide: AuthStorageService, useValue: authStorageSpy }
      ]
    });

    service = TestBed.inject(UserAuthService);
    httpMock = TestBed.inject(HttpTestingController);
    authStorageServiceSpy = TestBed.inject(AuthStorageService) as jasmine.SpyObj<AuthStorageService>;
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should send a POST request to login API endpoint with correct headers and body', () => {
    const userName = 'testuser';
    const password = 'testpass';

    service.login(userName, password).subscribe();

    const req = httpMock.expectOne(AUTH_URLS.LOGIN);
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('authorization')).toBe(`Basic ${btoa(userName + ':' + password)}`);
    expect(req.request.body).toEqual({});

    req.flush({});
  });

  it('should clear authentication-related information when logout is called', () => {
    service.logout();
    expect(authStorageServiceSpy.clear).toHaveBeenCalled();
  });

  it('should return true from isLoggedIn method when role and token are present', () => {
    authStorageServiceSpy.getRole.and.returnValue('admin');
    authStorageServiceSpy.getToken.and.returnValue('testtoken');

    const result = service.isLoggedIn();

    expect(result).toBeTrue();
    expect(authStorageServiceSpy.getRole).toHaveBeenCalled();
    expect(authStorageServiceSpy.getToken).toHaveBeenCalled();
  });

  it('should return false from isLoggedIn method when role or token is missing', () => {
    authStorageServiceSpy.getRole.and.returnValue('admin');
    authStorageServiceSpy.getToken.and.returnValue(null);

    const result = service.isLoggedIn();

    expect(result).toBeFalse();
    expect(authStorageServiceSpy.getRole).toHaveBeenCalled();
    expect(authStorageServiceSpy.getToken).toHaveBeenCalled();
  });

  it('should return true from roleMatch method when user role matches allowed role', () => {
    authStorageServiceSpy.getRole.and.returnValue('admin');

    const result = service.roleMatch('admin');

    expect(result).toBeTrue();
    expect(authStorageServiceSpy.getRole).toHaveBeenCalled();
  });

  it('should return false from roleMatch method when user role does not match allowed role', () => {
    authStorageServiceSpy.getRole.and.returnValue('user');

    const result = service.roleMatch('admin');

    expect(result).toBeFalse();
    expect(authStorageServiceSpy.getRole).toHaveBeenCalled();
  });
});
