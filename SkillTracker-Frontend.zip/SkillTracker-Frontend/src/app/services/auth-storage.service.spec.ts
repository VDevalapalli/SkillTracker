// import { TestBed } from '@angular/core/testing';

// import { AuthStorageService } from './auth-storage.service';

// describe('AuthStorageService', () => {
//   let service: AuthStorageService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(AuthStorageService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });


import { AuthStorageService } from './auth-storage.service';

describe('AuthStorageService', () => {
  let service: AuthStorageService;

  beforeEach(() => {
    service = new AuthStorageService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('setToken', () => {
    it('should set the token in sessionStorage', () => {
      spyOn(sessionStorage, 'setItem');
      service.setToken('jwt-token');
      expect(sessionStorage.setItem).toHaveBeenCalledWith('auth-token', 'jwt-token');
    });
  });

  describe('getToken', () => {
    it('should get the token from sessionStorage', () => {
      spyOn(sessionStorage, 'getItem').and.returnValue('jwt-token');
      expect(service.getToken()).toEqual('jwt-token');
    });
  });

  describe('setAuthenticatedUser', () => {
    it('should set the authenticated user in sessionStorage', () => {
      spyOn(sessionStorage, 'setItem');
      const user = { name: 'John', email: 'john@example.com' };
      service.setAuthenticatedUser(user);
      expect(sessionStorage.setItem).toHaveBeenCalledWith('auth-user', JSON.stringify(user));
    });
  });

  describe('getAuthenticatedUser', () => {
    it('should get the authenticated user from sessionStorage', () => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify({ name: 'John', email: 'john@example.com' }));
      expect(service.getAuthenticatedUser()).toEqual({ name: 'John', email: 'john@example.com' });
    });

    it('should return an empty object if user is not found in sessionStorage', () => {
      spyOn(sessionStorage, 'getItem').and.returnValue(null);
      expect(service.getAuthenticatedUser()).toEqual({});
    });
  });

  describe('getRole', () => {
    it('should get the role of the authenticated user from sessionStorage', () => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify({ name: 'John', email: 'john@example.com', userRole: 'admin' }));
      expect(service.getRole()).toEqual('admin');
    });

    it('should return an empty string if user is not found in sessionStorage', () => {
      spyOn(sessionStorage, 'getItem').and.returnValue(null);
      expect(service.getRole()).toEqual('');
    });
  });

  describe('isLoggedIn', () => {
    it('should return true if token is present in sessionStorage', () => {
      spyOn(service, 'getToken').and.returnValue('jwt-token');
      expect(service.isLoggedIn()).toEqual('jwt-token');
    });

    it('should return false if token is not present in sessionStorage', () => {
      spyOn(service, 'getToken').and.returnValue(null);
      expect(service.isLoggedIn()).toBeNull;
    });
  });

  describe('clear', () => {
    it('should clear the sessionStorage', () => {
      spyOn(sessionStorage, 'clear');
      service.clear();
      expect(sessionStorage.clear).toHaveBeenCalled();
    });
  });
});
