// import { TestBed } from '@angular/core/testing';

// import { SkillProfileService } from './skill-profile.service';

// describe('SkillProfileService', () => {
//   let service: SkillProfileService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(SkillProfileService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });


import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SkillProfileService } from './skill-profile.service';
import { Skillprofile } from '../model/skillprofile.model';
import { AuthStorageService } from './auth-storage.service';
import { COMMAND_URLS, QUERY_URLS } from '../constants/api-url.const';

describe('SkillProfileService', () => {
  let service: SkillProfileService;
  let httpMock: HttpTestingController;
  let authStorageService: AuthStorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ SkillProfileService, AuthStorageService ]
    });

    service = TestBed.inject(SkillProfileService);
    httpMock = TestBed.inject(HttpTestingController);
    authStorageService = TestBed.inject(AuthStorageService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should send a POST request to add a skill profile', () => {
    const skillProfile: Skillprofile = {
      associateId: 'CTS12345', technicalSkills: [{ skillName: 'HTML-CSS-JAVASCRIPT', expertiseLevel: 15 }], nonTechnicalSkills: [{ skillName: 'SPOKEN', expertiseLevel: 15 }],
      profileId: 0,
      profileName: '',
      mobile: '',
      email: ''
    };

    service.addSkillProfile(skillProfile).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(COMMAND_URLS.ADD_PROFILE);
    expect(req.request.method).toBe('POST');
    req.flush(skillProfile);
  });

  it('should send a PUT request to update a skill profile', () => {
    const skillProfile: Skillprofile = {
      profileId: 1, associateId: 'CTS12345', technicalSkills: [{ skillName: 'HTML-CSS-JAVASCRIPT', expertiseLevel: 17 }], nonTechnicalSkills: [{ skillName: 'SPOKEN', expertiseLevel: 17 }],
      profileName: '',
      mobile: '',
      email: ''
    };

    service.updateSkillProfile(skillProfile).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(COMMAND_URLS.UPDATE_PROFILE+'/1');
    expect(req.request.method).toBe('PUT');
    req.flush(skillProfile);
  });

  it('should send a GET request to retrieve a skill profile', () => {
    const associateId = 123;

    service.getSkillProfile(associateId).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(QUERY_URLS.SEARCH_SKILLS+'/ASSOCIATE_ID/123');
    expect(req.request.method).toBe('GET');
    req.flush({});
  });

  it('should send a GET request to search skill profiles', () => {
    const searchCriteria = { criteria: 'TECHNICAL_SKILLS', criteriaValue: 'Java' };

    service.searchProfiles(searchCriteria).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(QUERY_URLS.SEARCH_SKILLS+'/TECHNICAL_SKILLS/Java');
    expect(req.request.method).toBe('GET');
    req.flush([]);
  });
});
