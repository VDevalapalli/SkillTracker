export class Skill {
  skillId: string | undefined;
  skillName: string | undefined;
}
