import { Skillprofile } from './skillprofile.model';

describe('Skillprofile', () => {
  it('should create an instance', () => {
    expect(new Skillprofile()).toBeTruthy();
  });
});
