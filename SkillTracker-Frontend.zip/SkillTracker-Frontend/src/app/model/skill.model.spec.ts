import { Skill } from './skill.model';

describe('Skill', () => {
  it('should create an instance', () => {
    expect(new Skill()).toBeTruthy();
  });
});
