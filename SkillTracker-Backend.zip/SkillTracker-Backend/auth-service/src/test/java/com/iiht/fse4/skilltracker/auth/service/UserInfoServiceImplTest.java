package com.iiht.fse4.skilltracker.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.iiht.fse4.skilltracker.auth.entity.UserInfoEntity;
import com.iiht.fse4.skilltracker.auth.model.AddUserResponse;
import com.iiht.fse4.skilltracker.auth.model.UserInfo;
import com.iiht.fse4.skilltracker.auth.model.ValidateUserResponse;
import com.iiht.fse4.skilltracker.auth.repository.UserInfoRepository;
import com.iiht.fse4.skilltracker.auth.util.EncryptionUtil;
import com.iiht.fse4.skilltracker.auth.util.JwtTokenUtil;
import io.jsonwebtoken.impl.DefaultClaims;
import io.jsonwebtoken.impl.DefaultJws;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {UserInfoServiceImpl.class})
@ExtendWith(SpringExtension.class)
class UserInfoServiceImplTest {
    @MockBean
    private EncryptionUtil encryptionUtil;

    @MockBean
    private JwtTokenUtil jwtTokenUtil;

    @MockBean
    private UserInfoRepository userInfoRepository;

    @Autowired
    private UserInfoServiceImpl userInfoServiceImpl;

    /**
     * Method under test: {@link UserInfoServiceImpl#addUser(UserInfo)}
     */
    @Test
    void testAddUser() {
        when(encryptionUtil.encrypt((String) any())).thenReturn("Encrypt");

        UserInfoEntity userInfoEntity = new UserInfoEntity();
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        userInfoEntity.setCreatedDate(fromResult);
        userInfoEntity.setPassword("iloveyou");
        userInfoEntity.setToken("ABC123");
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult1 = Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant());
        userInfoEntity.setUpdatedDate(fromResult1);
        userInfoEntity.setUserEmail("jane.doe@example.org");
        userInfoEntity.setUserInfoId(123);
        userInfoEntity.setUserName("janedoe");
        userInfoEntity.setUserRole("User Role");
        when(userInfoRepository.save((UserInfoEntity) any())).thenReturn(userInfoEntity);
        UserInfo userInfo = mock(UserInfo.class);
        when(userInfo.getEmailId()).thenReturn("42");
        when(userInfo.getPassword()).thenReturn("iloveyou");
        when(userInfo.getUserName()).thenReturn("janedoe");
        when(userInfo.getUserRole()).thenReturn("User Role");
        AddUserResponse actualAddUserResult = userInfoServiceImpl.addUser(userInfo);
        assertEquals("Authentication Success", actualAddUserResult.getMessage());
        assertEquals(HttpStatus.OK, actualAddUserResult.getStatus());
        UserInfo userInfo1 = actualAddUserResult.getUserInfo();
        assertEquals("User Role", userInfo1.getUserRole());
        assertEquals("janedoe", userInfo1.getUserName());
        assertEquals(123, userInfo1.getUserInfoId());
        assertSame(fromResult1, userInfo1.getUpdatedDate());
        assertNull(userInfo1.getPassword());
        assertEquals("42", userInfo1.getEmailId());
        assertSame(fromResult, userInfo1.getCreatedDate());
        verify(encryptionUtil).encrypt((String) any());
        verify(userInfoRepository).save((UserInfoEntity) any());
        verify(userInfo, atLeast(1)).getEmailId();
        verify(userInfo).getPassword();
        verify(userInfo).getUserName();
        verify(userInfo, atLeast(1)).getUserRole();
    }

    /**
     * Method under test: {@link UserInfoServiceImpl#addUser(UserInfo)}
     */
    @Test
    void testAddUser2() {
        when(encryptionUtil.encrypt((String) any())).thenReturn("Encrypt");
        UserInfoEntity userInfoEntity = mock(UserInfoEntity.class);
        when(userInfoEntity.getUserInfoId()).thenReturn(123);
        when(userInfoEntity.getUserName()).thenReturn("janedoe");
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        when(userInfoEntity.getCreatedDate()).thenReturn(fromResult);
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult1 = Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant());
        when(userInfoEntity.getUpdatedDate()).thenReturn(fromResult1);
        doNothing().when(userInfoEntity).setCreatedDate((Date) any());
        doNothing().when(userInfoEntity).setPassword((String) any());
        doNothing().when(userInfoEntity).setToken((String) any());
        doNothing().when(userInfoEntity).setUpdatedDate((Date) any());
        doNothing().when(userInfoEntity).setUserEmail((String) any());
        doNothing().when(userInfoEntity).setUserInfoId(anyInt());
        doNothing().when(userInfoEntity).setUserName((String) any());
        doNothing().when(userInfoEntity).setUserRole((String) any());
        LocalDateTime atStartOfDayResult2 = LocalDate.of(1970, 1, 1).atStartOfDay();
        userInfoEntity.setCreatedDate(Date.from(atStartOfDayResult2.atZone(ZoneId.of("UTC")).toInstant()));
        userInfoEntity.setPassword("iloveyou");
        userInfoEntity.setToken("ABC123");
        LocalDateTime atStartOfDayResult3 = LocalDate.of(1970, 1, 1).atStartOfDay();
        userInfoEntity.setUpdatedDate(Date.from(atStartOfDayResult3.atZone(ZoneId.of("UTC")).toInstant()));
        userInfoEntity.setUserEmail("jane.doe@example.org");
        userInfoEntity.setUserInfoId(123);
        userInfoEntity.setUserName("janedoe");
        userInfoEntity.setUserRole("User Role");
        when(userInfoRepository.save((UserInfoEntity) any())).thenReturn(userInfoEntity);
        UserInfo userInfo = mock(UserInfo.class);
        when(userInfo.getEmailId()).thenReturn("42");
        when(userInfo.getPassword()).thenReturn("iloveyou");
        when(userInfo.getUserName()).thenReturn("janedoe");
        when(userInfo.getUserRole()).thenReturn("User Role");
        AddUserResponse actualAddUserResult = userInfoServiceImpl.addUser(userInfo);
        assertEquals("Authentication Success", actualAddUserResult.getMessage());
        assertEquals(HttpStatus.OK, actualAddUserResult.getStatus());
        UserInfo userInfo1 = actualAddUserResult.getUserInfo();
        assertEquals("User Role", userInfo1.getUserRole());
        assertEquals("janedoe", userInfo1.getUserName());
        assertEquals(123, userInfo1.getUserInfoId());
        assertSame(fromResult1, userInfo1.getUpdatedDate());
        assertNull(userInfo1.getPassword());
        assertEquals("42", userInfo1.getEmailId());
        assertSame(fromResult, userInfo1.getCreatedDate());
        verify(encryptionUtil).encrypt((String) any());
        verify(userInfoRepository).save((UserInfoEntity) any());
        verify(userInfoEntity).getUserInfoId();
        verify(userInfoEntity).getUserName();
        verify(userInfoEntity).getCreatedDate();
        verify(userInfoEntity).getUpdatedDate();
        verify(userInfoEntity).setCreatedDate((Date) any());
        verify(userInfoEntity).setPassword((String) any());
        verify(userInfoEntity).setToken((String) any());
        verify(userInfoEntity).setUpdatedDate((Date) any());
        verify(userInfoEntity).setUserEmail((String) any());
        verify(userInfoEntity).setUserInfoId(anyInt());
        verify(userInfoEntity).setUserName((String) any());
        verify(userInfoEntity).setUserRole((String) any());
        verify(userInfo, atLeast(1)).getEmailId();
        verify(userInfo).getPassword();
        verify(userInfo).getUserName();
        verify(userInfo, atLeast(1)).getUserRole();
    }

    /**
     * Method under test: {@link UserInfoServiceImpl#addUser(UserInfo)}
     */
    @Test
    void testAddUser3() {
        when(encryptionUtil.encrypt((String) any())).thenReturn("Encrypt");
        UserInfoEntity userInfoEntity = mock(UserInfoEntity.class);
        when(userInfoEntity.getUserInfoId()).thenReturn(123);
        when(userInfoEntity.getUserName()).thenReturn("janedoe");
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        when(userInfoEntity.getCreatedDate()).thenReturn(fromResult);
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult1 = Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant());
        when(userInfoEntity.getUpdatedDate()).thenReturn(fromResult1);
        doNothing().when(userInfoEntity).setCreatedDate((Date) any());
        doNothing().when(userInfoEntity).setPassword((String) any());
        doNothing().when(userInfoEntity).setToken((String) any());
        doNothing().when(userInfoEntity).setUpdatedDate((Date) any());
        doNothing().when(userInfoEntity).setUserEmail((String) any());
        doNothing().when(userInfoEntity).setUserInfoId(anyInt());
        doNothing().when(userInfoEntity).setUserName((String) any());
        doNothing().when(userInfoEntity).setUserRole((String) any());
        LocalDateTime atStartOfDayResult2 = LocalDate.of(1970, 1, 1).atStartOfDay();
        userInfoEntity.setCreatedDate(Date.from(atStartOfDayResult2.atZone(ZoneId.of("UTC")).toInstant()));
        userInfoEntity.setPassword("iloveyou");
        userInfoEntity.setToken("ABC123");
        LocalDateTime atStartOfDayResult3 = LocalDate.of(1970, 1, 1).atStartOfDay();
        userInfoEntity.setUpdatedDate(Date.from(atStartOfDayResult3.atZone(ZoneId.of("UTC")).toInstant()));
        userInfoEntity.setUserEmail("jane.doe@example.org");
        userInfoEntity.setUserInfoId(123);
        userInfoEntity.setUserName("janedoe");
        userInfoEntity.setUserRole("User Role");
        when(userInfoRepository.save((UserInfoEntity) any())).thenReturn(userInfoEntity);
        UserInfo userInfo = mock(UserInfo.class);
        when(userInfo.getEmailId()).thenReturn("42");
        when(userInfo.getPassword()).thenReturn("iloveyou");
        when(userInfo.getUserName()).thenReturn("janedoe");
        when(userInfo.getUserRole()).thenReturn("");
        AddUserResponse actualAddUserResult = userInfoServiceImpl.addUser(userInfo);
        assertEquals("Authentication Success", actualAddUserResult.getMessage());
        assertEquals(HttpStatus.OK, actualAddUserResult.getStatus());
        UserInfo userInfo1 = actualAddUserResult.getUserInfo();
        assertEquals("", userInfo1.getUserRole());
        assertEquals("janedoe", userInfo1.getUserName());
        assertEquals(123, userInfo1.getUserInfoId());
        assertSame(fromResult1, userInfo1.getUpdatedDate());
        assertNull(userInfo1.getPassword());
        assertEquals("42", userInfo1.getEmailId());
        assertSame(fromResult, userInfo1.getCreatedDate());
        verify(encryptionUtil).encrypt((String) any());
        verify(userInfoRepository).save((UserInfoEntity) any());
        verify(userInfoEntity).getUserInfoId();
        verify(userInfoEntity).getUserName();
        verify(userInfoEntity).getCreatedDate();
        verify(userInfoEntity).getUpdatedDate();
        verify(userInfoEntity).setCreatedDate((Date) any());
        verify(userInfoEntity).setPassword((String) any());
        verify(userInfoEntity).setToken((String) any());
        verify(userInfoEntity).setUpdatedDate((Date) any());
        verify(userInfoEntity).setUserEmail((String) any());
        verify(userInfoEntity).setUserInfoId(anyInt());
        verify(userInfoEntity).setUserName((String) any());
        verify(userInfoEntity).setUserRole((String) any());
        verify(userInfo, atLeast(1)).getEmailId();
        verify(userInfo).getPassword();
        verify(userInfo).getUserName();
        verify(userInfo, atLeast(1)).getUserRole();
    }

    /**
     * Method under test: {@link UserInfoServiceImpl#authenticateUser(Pair)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testAuthenticateUser() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException
        //       at com.iiht.fse4.skilltracker.auth.service.UserInfoServiceImpl.authenticateUser(UserInfoServiceImpl.java:107)
        //   See https://diff.blue/R013 to resolve this issue.

        userInfoServiceImpl.authenticateUser(null);
    }

    /**
     * Method under test: {@link UserInfoServiceImpl#validateUser(String)}
     */
    @Test
    void testValidateUser() throws NoSuchAlgorithmException, InvalidKeySpecException {
        when(jwtTokenUtil.validateToken((String) any()))
                .thenReturn(new DefaultJws<>(null, new DefaultClaims(), "Signature"));
        ValidateUserResponse actualValidateUserResult = userInfoServiceImpl.validateUser("ABC123");
        assertEquals("Authentication Success", actualValidateUserResult.getMessage());
        assertEquals(HttpStatus.OK, actualValidateUserResult.getStatus());
        verify(jwtTokenUtil).validateToken((String) any());
    }

    /**
     * Method under test: {@link UserInfoServiceImpl#validateUser(String)}
     */
    @Test
    void testValidateUser2() throws NoSuchAlgorithmException, InvalidKeySpecException {
        when(jwtTokenUtil.validateToken((String) any())).thenReturn(null);
        ValidateUserResponse actualValidateUserResult = userInfoServiceImpl.validateUser("ABC123");
        assertNull(actualValidateUserResult.getMessage());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualValidateUserResult.getStatus());
        verify(jwtTokenUtil).validateToken((String) any());
    }
}

